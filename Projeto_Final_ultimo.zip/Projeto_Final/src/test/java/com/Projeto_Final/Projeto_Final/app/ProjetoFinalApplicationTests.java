package com.Projeto_Final.Projeto_Final.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
